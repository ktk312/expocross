self.__precacheManifest = [
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/expo-gh-pages/./fonts/Foundation.ttf"
  },
  {
    "revision": "5b5e6b9e0659ae57fe94",
    "url": "/expo-gh-pages/static/js/app.68ae64b5.chunk.js"
  },
  {
    "revision": "d4ed37a1146ea63eb0dc",
    "url": "/expo-gh-pages/static/js/runtime~app.bf104491.js"
  },
  {
    "revision": "5a293a273bee8d740a045d9922b9a9ae",
    "url": "/expo-gh-pages/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "6af86321ef76edc94785168543427b7c",
    "url": "/expo-gh-pages/index.html"
  },
  {
    "revision": "80adb197e770af663f33fa430f17fc17",
    "url": "/expo-gh-pages/manifest.json"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/expo-gh-pages/serve.json"
  },
  {
    "revision": "1f1ad4ebe3f3a328e1e4",
    "url": "/expo-gh-pages/static/js/2.49381c66.chunk.js"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/expo-gh-pages/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "872545dde71de3842234bf6afe80c4cb",
    "url": "/expo-gh-pages/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/expo-gh-pages/./fonts/Ionicons.ttf"
  },
  {
    "revision": "5e695e96a003a79f7f97060bf49409a9",
    "url": "/expo-gh-pages/expo-service-worker.js"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/expo-gh-pages/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/expo-gh-pages/favicon.ico"
  },
  {
    "revision": "c6aef942e3668158ec29d4adcb2e768f",
    "url": "/expo-gh-pages/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/expo-gh-pages/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/expo-gh-pages/./fonts/Feather.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/expo-gh-pages/./fonts/Entypo.ttf"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/expo-gh-pages/./fonts/AntDesign.ttf"
  }
];